package com.example.app3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.app3.ui.theme.App3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            apka_licznik()
        }
    }
}

@Composable
fun apka_licznik(){
    val navController = rememberNavController()

    var licznik by remember {mutableIntStateOf(0)}

    NavHost(navController = navController, startDestination = "ekran1"){
        composable("ekran1"){
            EkranLicznik(
                licznik = licznik,
                zwieksz = {licznik++},
                onIdzDoDrugiego = {navController.navigate("ekran2")},
                onIdzDoTrzeciego = {navController.navigate("ekran3")}
            )
        }
        composable("ekran2"){
            DrugiEkran(
                licznik = licznik,
                onIdzDoTrzeciego = {navController.navigate("ekran3")},
                onIdzDoPierwszego = {navController.navigate("ekran1")}
            )
        }

        composable("ekran3"){
            TrzeciEkran(
                licznik = licznik,
                onIdzDoPierwszego = {navController.navigate("ekran1")},
                onIdzDoDrugiego = {navController.navigate("ekran2")}
            )
        }
    }
}

@Composable
fun EkranLicznik(licznik: Int, zwieksz: () -> Unit, onIdzDoDrugiego: () -> Unit, onIdzDoTrzeciego: () -> Unit) {

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(text = "Licznik klikniec: $licznik",fontSize = 30.sp) //tu tekst do licznika i nizej obsluga przycisku
        Spacer(modifier = Modifier.height(30.dp))

        Button(onClick = zwieksz) {
            Text(text = "Kliknij")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoDrugiego) {
            Text(text = "Powrót do 2")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoTrzeciego) {
            Text(text = "Powrót do 3")
        }
    }
}

@Composable
fun DrugiEkran(licznik: Int,onIdzDoTrzeciego: () -> Unit, onIdzDoPierwszego: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Licznik kliknięć: $licznik", fontSize = 24.sp)
        Text(text = "Drugi Ekran", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoTrzeciego) {
            Text(text = "Powrót do 3")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoPierwszego) {
            Text(text = "Powrót do 1")
        }
    }
}

@Composable
fun TrzeciEkran(licznik: Int, onIdzDoPierwszego: () -> Unit, onIdzDoDrugiego: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Licznik kliknięć: $licznik", fontSize = 24.sp)
        Text(text = "Trzeci Ekran", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoPierwszego) {
            Text(text = "Powrót do 1")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onIdzDoDrugiego) {
            Text(text = "Powrót do 2")
        }
    }
}
